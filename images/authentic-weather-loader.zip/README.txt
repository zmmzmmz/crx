A Pen created at CodePen.io. You can find this one at https://codepen.io/tholman/pen/yenku.

 Loading animation for the new Authentic Weather website ~ http://authenticweather.com