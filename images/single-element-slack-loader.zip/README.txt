A Pen created at CodePen.io. You can find this one at https://codepen.io/CrocoDillon/pen/Htycs.

 This is the Slack loader, single element using only CSS. An idea proposed by Fabrice :)